document.getElementById("usage").addEventListener("click",function (){
    alert("Usage seports saved to downloads successfully!");
});
document.getElementById("perf").addEventListener("click",function (){
    alert("Performance reports saved to downloads successfully!");
});
document.getElementById("fin").addEventListener("click",function (){
    alert("Financial reports saved to downloads successfully!");
});