document.getElementById("backup").addEventListener("click",function (){
    alert("BackUp successful!");
});
document.getElementById("restore").addEventListener("click",function (){
    alert("Restore successful!");
});